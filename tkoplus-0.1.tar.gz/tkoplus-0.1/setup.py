from setuptools import setup

setup(
    name="tkoplus",
    version= "0.1",
    description='tkinter option plus',
    author="Vahid",
    author_email="vahidpy3@gmail.com",
    packages=['tkoplus']
)